package TESTS;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import tema3_ejerciciosIntegracion.Ej4_ServicioOrdenes;
import tema3_ejerciciosIntegracion.Ej4_ServicioPagos;

public class Ejercicio4Test {
    private Ej4_ServicioPagos servicioPagos;
    private Ej4_ServicioOrdenes servicioOrdenes;

    @BeforeEach
    void setUp() {
        servicioPagos = new Ej4_ServicioPagos();//Simulamos la clase del servicio de pagos
        servicioOrdenes = new Ej4_ServicioOrdenes(servicioPagos);
    }

    @Test
    void testProcesarOrdenConPagoExitoso() {
        double montoOrden = 200.0;

        //Antes de procesar el pago, aseguramos que hay monto suficiente llamando al metodo que procesa la orden introduciendo un monto que debe ser válido
        assertTrue(servicioOrdenes.procesarOrden(montoOrden), 
            "La orden debería procesarse correctamente con un pago exitoso.");
    }

    @Test
    void testProcesarOrdenConMontoInvalido() {
        double montoOrden = -50.0;

        //Ahora con un monto negativo deberia devolvernos que no se puede procesar la orden con un saldo negativo 
        assertFalse(servicioOrdenes.procesarOrden(montoOrden), 
            "No se debe procesar una orden con monto negativo.");
    }

    @Test
    void testProcesarOrdenConFondosInsuficientes() {
        double montoOrden = 1500.0; //Introducimos un monto mayor que el saldo disponible (1000)

        //No debería procesarse si el monto es mayor que el saldo 
        assertFalse(servicioOrdenes.procesarOrden(montoOrden), 
            "No se debe procesar una orden si el pago es mayor que el saldo que sale como 1000.");
    }
}

