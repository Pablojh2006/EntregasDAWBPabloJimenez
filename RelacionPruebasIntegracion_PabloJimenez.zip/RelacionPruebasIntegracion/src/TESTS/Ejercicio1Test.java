package TESTS;

import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import tema3_ejerciciosIntegracion.Ej1_BaseDeDatos;
import tema3_ejerciciosIntegracion.Ej1_ServicioUsuarios;

public class Ejercicio1Test {
    private Ej1_BaseDeDatos baseDeDatos;
    private Ej1_ServicioUsuarios servicioUsuarios;

    @BeforeEach
    void setUp() {
        baseDeDatos = new Ej1_BaseDeDatos();//Simulamos de la base de datos
        servicioUsuarios = new Ej1_ServicioUsuarios(baseDeDatos);
    }

    @Test
    void testRegistrarYVerificarUsuario() {
        //Entrada del usuario con nombre Carlos 
        String usuario = "Carlos";
        
        //Llamo al metodo de registrar un usuario
        servicioUsuarios.registrarUsuario(usuario);
        
        //Verificar si devuelve como True al UsuarioRegistrado
        assertTrue(servicioUsuarios.usuarioRegistrado(usuario), 
                   "El usuario debería estar registrado en la base de datos");
    }
}
