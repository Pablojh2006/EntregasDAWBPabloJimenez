package TESTS;

import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import tema3_ejerciciosIntegracion.Ej2_ServicioEnvio;
import tema3_ejerciciosIntegracion.Ej2_ServicioPedido;

public class Ejercicio2Test {
    private Ej2_ServicioEnvio servicioEnvio;
    private Ej2_ServicioPedido servicioPedido;

    @BeforeEach
    void setUp() {
        servicioEnvio = new Ej2_ServicioEnvio();//Simulamos la clase del servicio de envío
        servicioPedido = new Ej2_ServicioPedido(servicioEnvio);
    }

    @Test
    void testCrearYEnviarPedido() {
        //Introducimos como pedido el pedido "Pedido 123"
        String pedido = "Pedido 123";

        //Llamamos al metodo de crear y enviar un pedido que devolverá true o false según se haya creado y enviado
        boolean enviado = servicioPedido.crearYEnviarPedido(pedido);

        //Verificamos si es true el pedido se ha enviado correctamente
        assertTrue(enviado, "El pedido debería haberse enviado correctamente");
    }
}
