package TESTS;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import tema3_ejerciciosIntegracion.Ej3_BaseDeDatosProductos;
import tema3_ejerciciosIntegracion.Ej3_GestorProductos;

public class Ejercicio3Test {
    private Ej3_BaseDeDatosProductos baseDeDatos;
    private Ej3_GestorProductos gestorProductos;

    @BeforeEach
    void setUp() {
        baseDeDatos = new Ej3_BaseDeDatosProductos();//Simulamos la base de datos de los productos
        gestorProductos = new Ej3_GestorProductos(baseDeDatos);
    }

    @Test
    void testRegistrarYVerificarProducto() {
        String producto = "Laptop";//Introducimos producto como "Laptop"

        //Antes de registrar, el producto no debería estar en la base de datos ya que no hemos echo nada aún
        assertFalse(gestorProductos.productoRegistrado(producto), "El producto NO debería estar registrado aún");

        //Registramos el producto llamando al método
        gestorProductos.registrarProducto(producto);

        //Después de registrar el producto, el producto debería existir en la base de datos
        assertTrue(gestorProductos.productoRegistrado(producto), "El producto debería estar registrado correctamente");
    }
}
