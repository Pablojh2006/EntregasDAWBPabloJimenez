package tema3_ejerciciosIntegracion;

public class Ej2_ServicioEnvio {
    public boolean enviarPedido(String pedido) {
        System.out.println("Enviando pedido: " + pedido);
        return true;
    }
}