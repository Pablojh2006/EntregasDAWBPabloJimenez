/**
 * 
 */
/**
 * 
 */
module RelacionPruebasIntegracion {
	requires org.junit.jupiter.api;
}