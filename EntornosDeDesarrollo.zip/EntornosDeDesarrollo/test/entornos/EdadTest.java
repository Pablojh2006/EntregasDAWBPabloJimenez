package entornos;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class EdadTest {

	@Test
	void testEquivalenciaValida() {
		// Pruebas dentro del rango válido (18 - 100)
		assertTrue(Edad.esMayorDeEdad(18), "18 debería ser mayor de edad");
		assertTrue(Edad.esMayorDeEdad(50), "50 debería ser mayor de edad");
		assertTrue(Edad.esMayorDeEdad(100), "100 debería ser mayor de edad");
	}

	@Test
	void testEquivalenciaInvalida() {
		// Pruebas fuera del rango válido
		assertFalse(Edad.esMayorDeEdad(0), "0 no debería ser mayor de edad");
		assertFalse(Edad.esMayorDeEdad(17), "17 no debería ser mayor de edad");
		assertFalse(Edad.esMayorDeEdad(101), "101 no debería ser mayor de edad");
		assertFalse(Edad.esMayorDeEdad(-5), "-5 no debería ser mayor de edad");
	}

	@Test
	void testLimiteInferior() {
		// Prueba en el límite inferior
		assertTrue(Edad.esMayorDeEdad(18), "18 debería ser mayor de edad");
		assertFalse(Edad.esMayorDeEdad(17), "17 no debería ser mayor de edad");
		assertFalse(Edad.esMayorDeEdad(0), "0 no debería ser mayor de edad");
	}

	@Test
	void testLimiteSuperior() {
		// Prueba en el límite superior
		assertTrue(Edad.esMayorDeEdad(100), "100 debería ser mayor de edad");
		assertFalse(Edad.esMayorDeEdad(101), "101 no debería ser mayor de edad");
	}
}

